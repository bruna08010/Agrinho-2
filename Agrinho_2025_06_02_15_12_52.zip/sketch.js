// Variáveis globais do jogo
let plantas = []; // Array para armazenar as plantas (árvores e trigo)
let lixos = []; // Array para armazenar os itens de lixo
let temperatura = 10; // Temperatura inicial do planeta
let totalPlantas = 0; // Contador de plantas cultivadas
let perguntas = []; // Array de perguntas do quiz
let perguntaAtual; // Pergunta atual sendo exibida
let respondendo = true; // Flag para controlar se o jogador pode responder
let corFundoAtual; // Cor de fundo da tela

/**
 * Função de configuração do p5.js, executada uma vez no início.
 */
function setup() {
  createCanvas(700, 500); // Cria um canvas de 700x500 pixels
  textAlign(CENTER, CENTER); // Alinha o texto ao centro
  gerarPerguntas(); // Gera as perguntas do quiz
  novaPergunta(); // Carrega a primeira pergunta
  corFundoAtual = color(217, 112, 26); // Define a cor inicial do fundo (laranja terroso)
}

/**
 * Função de desenho do p5.js, executada continuamente.
 */
function draw() {
  background(corFundoAtual); // Define a cor de fundo

  mostrarCabecalho(); // Exibe o cabeçalho do jogo
  mostrarPergunta(); // Exibe a pergunta e opções

  temperatura += 0.01; // Aumenta a temperatura gradualmente
  verificarFimDeJogo(); // Verifica as condições de fim de jogo

  // Desenha todas as plantas na tela
  for (let planta of plantas) {
    planta.mostrar();
  }

  // Desenha todos os lixos na tela
  for (let lixo of lixos) {
    lixo.mostrar();
  }
}

/**
 * Exibe o cabeçalho do jogo com o título, temperatura e contagem de plantas.
 */
function mostrarCabecalho() {
  fill(20); // Cor do texto (quase preto)
  textSize(20); // Tamanho da fonte
  text("🌱 ℚ𝕌𝕀ℤ 𝔻𝕆 𝕄𝔼𝕀𝕆 𝔸𝕄𝔹𝕀𝔼ℕ𝕋𝔼 - 𝕊𝔸𝕃𝕍𝔼 𝕆 ℙ𝕃𝔸ℕ𝔼𝕋𝔸", width / 2, 60);

  textSize(16);
  text(`𝕋𝕖𝕞𝕡𝕖𝕣𝕒𝕥𝕦𝕣𝕒: ${temperatura.toFixed(1)}°C    |    ℙ𝕝𝕒𝕟𝕥𝕒: ${totalPlantas}`, width / 2, 100);
}

/**
 * Exibe a pergunta atual e suas opções na tela.
 */
function mostrarPergunta() {
  if (respondendo && perguntaAtual) {
    fill(0); // Cor do texto da pergunta (preto)
    textSize(22);
    text(perguntaAtual.pergunta, width / 2, 150);

    textSize(20);
    fill('black');
    text("A) " + perguntaAtual.opcoes[0], width / 2, 220); // Opção A
    fill('black');
    text("B) " + perguntaAtual.opcoes[1], width / 2, 260); // Opção B

    textSize(14);
    fill(80); // Cor do texto de instrução (cinza)
    text("ᵖʳᵉˢˢᶦᵒⁿᵉ ᵃ ᵒᵘ ᵇ ᵖᵃʳᵃ ʳᵉˢᵖᵒⁿᵈᵉʳ", width / 2, 390);
  }
}

/**
 * Verifica as condições de vitória ou derrota do jogo.
 */
function verificarFimDeJogo() {
  // Condição de vitória: número de plantas maior ou igual à temperatura
  if (totalPlantas >= temperatura) {
    fill(0); // Cor do texto (preto)
    textSize(24);
    text("🌎𝕍𝕠𝕔𝕖 𝕤𝕒𝕝𝕧𝕠𝕦 𝕠 𝕡𝕝𝕒𝕟𝕖𝕥𝕒 𝕔𝕠𝕞 𝕔𝕠𝕟𝕙𝕖𝕔𝕚𝕞𝕖𝕟𝕥𝕠", width / 2, height / 2);
    noLoop(); // Para o loop de desenho (o jogo termina)
  }
  // Condição de derrota: temperatura excede 50°C
  else if (temperatura > 50) {
    fill(0); // Cor do texto (preto)
    textSize(24);
    text("🔥 ℙ𝕒𝕣𝕒𝕓𝕖𝕟𝕤 𝕧𝕠𝕔𝕖 𝕞𝕒𝕥𝕠𝕦 𝕥𝕠𝕕𝕠 𝕞𝕦𝕟𝕕𝕠", width / 2, height / 2);
    noLoop(); // Para o loop de desenho (o jogo termina)
  }
}

/**
 * Classe Planta para representar árvores e trigo no jogo.
 */
class Planta {
  /**
   * Construtor da classe Planta.
   * @param {number} x Posição X da planta.
   * @param {number} y Posição Y da planta.
   * @param {string} emoji Emoji que representa a planta (ex: "🌳", "🌾").
   */
  constructor(x, y, emoji) {
    this.x = x;
    this.y = y;
    this.emoji = emoji;
  }

  /**
   * Exibe a planta na tela.
   */
  mostrar() {
    textSize(24); // Tamanho do emoji
    text(this.emoji, this.x, this.y); // Desenha o emoji na posição
  }
}

/**
 * Classe Lixo para representar itens de lixo no jogo.
 */
class Lixo {
  /**
   * Construtor da classe Lixo.
   * @param {number} x Posição X do lixo.
   * @param {number} y Posição Y do lixo.
   * @param {string} emoji Emoji que representa o lixo (ex: "🗑️", "🍾", "🚮").
   */
  constructor(x, y, emoji) {
    this.x = x;
    this.y = y;
    this.emoji = emoji;
  }

  /**
   * Exibe o lixo na tela.
   */
  mostrar() {
    textSize(24); // Tamanho do emoji
    text(this.emoji, this.x, this.y); // Desenha o emoji na posição
  }
}

/**
 * Planta uma nova árvore ou trigo em uma posição aleatória.
 */
function plantarNovaPlanta() {
  let x = random(20, width - 30); // Posição X aleatória
  let y = random(height / 3 + 60, height - 40); // Posição Y aleatória
  let emoji;

  // Escolhe aleatoriamente entre árvore e trigo
  if (random() < 0.5) {
    emoji = "🌳"; // Árvore
  } else {
    emoji = "🌾"; // Trigo
  }

  plantas.push(new Planta(x, y, emoji)); // Adiciona a nova planta ao array
  totalPlantas++; // Incrementa o contador de plantas
}

/**
 * Gera novos itens de lixo em posições aleatórias.
 */
function gerarLixo() {
  const numLixos = floor(random(2, 5)); // Gera entre 2 e 4 itens de lixo
  const lixoEmojis = ["🗑️", "🍾", "🚮", "🥫"]; // Emojis de lixo

  for (let i = 0; i < numLixos; i++) {
    let x = random(20, width - 30); // Posição X aleatória
    let y = random(height / 3 + 60, height - 40); // Posição Y aleatória
    let emoji = random(lixoEmojis); // Escolhe um emoji de lixo aleatoriamente
    lixos.push(new Lixo(x, y, emoji)); // Adiciona o novo lixo ao array
  }
}

/**
 * Função chamada quando uma tecla é pressionada.
 */
function keyPressed() {
  if (respondendo && (key === 'a' || key === 'A')) {
    responder(0); // Responde com a opção A
  } else if (respondendo && (key === 'b' || key === 'B')) {
    responder(1); // Responde com a opção B
  }
}

/**
 * Processa a resposta do jogador.
 * @param {number} resposta O índice da opção escolhida (0 para A, 1 para B).
 */
function responder(resposta) {
  if (resposta === perguntaAtual.correta) {
    plantarNovaPlanta(); // Se a resposta estiver correta, planta uma nova planta
    lixos = []; // Limpa o array de lixo, fazendo o lixo desaparecer

    // Muda a cor do fundo para uma cor suave aleatória
    corFundoAtual = color(
      random(100, 200), // R
      random(150, 255), // G
      random(100, 200) // B
    );
  } else {
    gerarLixo(); // Se a resposta estiver incorreta, gera lixo
  }
  respondendo = false; // Impede novas respostas até a próxima pergunta
  setTimeout(novaPergunta, 800); // Carrega uma nova pergunta após 0.8 segundos
}

/**
 * Gera as perguntas do quiz, garantindo que as opções sejam alternadas.
 */
function gerarPerguntas() {
  // Define as perguntas com a resposta correta e incorreta
  let perguntasOriginais = [
    {
      pergunta: "O que ajuda a reduzir o aquecimento global?",
      corretaTexto: "Plantar árvores",
      incorretaTexto: "Queimar carvão"
    },
    {
      pergunta: "Qual ação polui menos o ar?",
      corretaTexto: "Usar bicicleta",
      incorretaTexto: "Dirigir sozinho"
    },
    {
      pergunta: "Qual desses materiais é reciclável?",
      corretaTexto: "Garrafa PET",
      incorretaTexto: "Casca de banana"
    },
    {
      pergunta: "Qual fonte de energia é renovável?",
      corretaTexto: "Solar",
      incorretaTexto: "Carvão"
    },
    {
      pergunta: "O que prejudica os oceanos?",
      corretaTexto: "Lixo plástico",
      incorretaTexto: "Alga marinha"
    },
    {
      pergunta: "Qual atitude economiza água?",
      corretaTexto: "Fechar a torneira ao escovar os dentes",
      incorretaTexto: "Lavar calçada com mangueira"
    },
    {
      pergunta: "O que causa desmatamento?",
      corretaTexto: "Corte ilegal de árvores",
      incorretaTexto: "Plantio responsável"
    },
    {
      pergunta: "Como podemos proteger os animais?",
      corretaTexto: "Preservando habitats naturais",
      incorretaTexto: "Caçando por esporte"
    }
  ];

  perguntas = []; // Limpa o array de perguntas
  // Para cada pergunta original, cria uma nova com opções alternadas
  for (let p of perguntasOriginais) {
    let opcoes = [];
    let correta;

    // Decide aleatoriamente se a resposta correta será a primeira ou a segunda opção
    if (random() < 0.5) {
      opcoes[0] = p.corretaTexto;
      opcoes[1] = p.incorretaTexto;
      correta = 0; // A resposta correta é a primeira opção
    } else {
      opcoes[0] = p.incorretaTexto;
      opcoes[1] = p.corretaTexto;
      correta = 1; // A resposta correta é a segunda opção
    }
    // Adiciona a pergunta formatada ao array de perguntas
    perguntas.push({
      pergunta: p.pergunta,
      opcoes: opcoes,
      correta: correta
    });
  }
  // Embaralha as perguntas para que apareçam em ordem aleatória
  perguntas = shuffle(perguntas);
}

/**
 * Carrega uma nova pergunta do array de perguntas.
 * Se todas as perguntas foram usadas, gera-as novamente.
 */
function novaPergunta() {
  if (perguntas.length === 0) {
    gerarPerguntas(); // Se não houver mais perguntas, gera-as novamente
  }
  perguntaAtual = perguntas.pop(); // Pega a última pergunta do array
  respondendo = true; // Permite que o jogador responda
}

// Função auxiliar para embaralhar um array (Fisher-Yates shuffle)
function shuffle(array) {
  let currentIndex = array.length, randomIndex;

  // Enquanto houver elementos para embaralhar.
  while (currentIndex !== 0) {
    // Escolhe um elemento restante.
    randomIndex = floor(random() * currentIndex);
    currentIndex--;

    // E o troca com o elemento atual.
    [array[currentIndex], array[randomIndex]] = [
      array[randomIndex], array[currentIndex]];
  }
  return array;
}